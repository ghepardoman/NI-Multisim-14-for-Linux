#!/bin/bash
export WINEPREFIX=~/.multisim143

/usr/local/bin/wine ~/.multisim143/drive_c/Program\ Files\ \(x86\)/National\ Instruments/Circuit\ Design\ Suite\ 14.3/multisim.exe
